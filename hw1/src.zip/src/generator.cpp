//  generator

#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <string>
#include <ctime>

using namespace std;

struct st {
    int pat;
    int chd;
};

int cmp(const int &a, const int &b) {
    return a > b;
}

int main() {
    srand((unsigned)time(NULL));
    int len = rand()%10+1;                         // the num of views
    vector<int> v;                                  // v contains views
    vector<st> r;                                   // r contains relations of views
    
    // randomly generate the views
    for (int i = 0; i < len; i++) {
        int temp = rand()%10000 +1;
        v.push_back(temp);
    }
    
    // descending sort the views
    sort(v.begin(), v.end(), cmp);
    
    
    // randomly generate the relations between views
    for(int i = 1; i < len; i++) {
        int num = pow(2, i);
        int rela_num = rand()%num + 1;
        if(rela_num == num) {
            rela_num = num - 1;  
        }
        int position = i - 1;
        while(position != -1) {
            if (1 == (rela_num % 2)) {
                st a;
                a.pat = position;
                a.chd = i;
                r.push_back(a);
            }
            rela_num /= 2;
            position--;
        }
    }
    
    string filename = "input.txt";
    const char *fileName = filename.c_str();
    
    ofstream ofs;
    ofs.open(fileName, std::ofstream::out);
    ofs << len << endl;
    cout << len << endl;
    for (int i = 0; i < len; i++) {
        ofs << i + 1 << " " << v[i] << endl; 
        cout << i + 1 << " " << v[i] << endl; 
    }
    ofs << r.size() << endl;
    cout << r.size() << endl;
    for (int i = 0; i < r.size(); i++) {
        ofs << r[i].pat + 1 << " " << r[i].chd + 1 << endl;
        cout << r[i].pat + 1 << " " << r[i].chd + 1 << endl;
    }
    if (ofs.good()) {
        cout << "The Generator finishes its job." << endl;
    }
    ofs.close();
    
    return 0;
    }
