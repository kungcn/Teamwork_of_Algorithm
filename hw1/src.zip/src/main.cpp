#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <string>
#include <unistd.h>
#include <sstream>
using namespace std;

//  to be compatible
#define nullptr NULL
#define MAX 500

//节点
class node {
public:
	//使用节点号和节点的视图个数来初始化节点
	node(int number, int val) {
		node_number = number;
		value = val;
		selected = 0;
	}
	//节点的视图个数
	int value;
	//节点号
	int node_number;
	//子节点们
	vector<node*> children;
	//父节点们
	vector<node*> parents;
	//当前继承的父节点
	node* present_parent;
	//该节点在前面轮是不是已经被选过了
	bool selected;
};

//函数名：递归寻子
//输入:节点a,节点b,保存结果的c（初始化为false）
//输出:如果节点a是b的孩子，那么将c附为true
void is_children(node* a, node* b, bool* c) {
	if (a == b) *c = true;
	for (int i = 0; i < a->children.size(); i++)
	{
		is_children(a->children[i], b, c);
	}
}

//函数名：递归求收益
//输入:root的递归子节点a,当前考虑的节点root,该子节点a的收益benefit，root相对于当前继承的父亲节点的收益root_benefit,is_visited保存当前节点是否已经被访问过
//输出:该子节点a的收益benefit
void calculate_benefit(node* a, node* root, int* benefit, int root_benefit, bool* is_visited) {
	for (int i = 0; i < a->children.size(); i++)
	{
		if (a->children[i] != nullptr) {
			if (is_visited[a->children[i]->node_number] == false) {
				bool c = false;
				if (a->children[i]->present_parent->value >= root->value) {
					*benefit += a->children[i]->present_parent->value - root->value;
				}
				is_visited[a->children[i]->node_number] = true;
				calculate_benefit(a->children[i], root, benefit, root_benefit, is_visited);
			}
		}
	}
}

//函数名：寻找最大收益的节点号
//输入：节点收益数组a,节点总数N
//输出：最大收益的节点号position
int find_biggest_position(int* a, int N) {
	int max = -100000000;
	int position;
	for (int i = 1; i <= N; i++) {
		if (a[i] > max) {
			max = a[i];
			position = i;
		}
	}
	return position;
}

//函数名：改变子节点当前继承的父亲节点
//输入：当前操作的节点a，当前胜出的节点winner
//输出：将子节点a当前继承的父亲节点改为winner
void change_children_present_father(node* a, node* winner) {
	if (a != nullptr) {
		if(winner->value<a->present_parent->value)
		a->present_parent = winner;
		for (int i = 0; i < a->children.size(); i++)
		{
			change_children_present_father(a->children[i], winner);
		}
	}
}


int main(int argc,char**argv) {

    //  record error and result
    //ofstream ofs;
    //ofs.open("log.txt", std::ofstream::out);

    int operationLetter = 0;
    char *inputFile = nullptr;
    int k;

    //  decode the command line
    while ((operationLetter = getopt(argc, argv, "k:f:")) != -1) {
        switch (operationLetter) {
        case 'f':
            inputFile = optarg;
            break;
        case 'k':
            string str(optarg);
            stringstream ss(str);
            ss >> k;
            break;
            //case '?':
            //ofs << "Unknown command!" << endl;
            //break;
        }
    }

	fstream fs;
	fs.open(inputFile);

    //  N is the number of view
    //  M is the number of relationship between views
	int N;
    int M;
	fs >> N;
	node** node_set = new node*[N + 1];
	for (int i = 1; i <= N; i++) {
		int node_number, value;
		fs >> node_number >> value;
		node* temp = new node(node_number, value);
		node_set[i] = temp;
		node_set[i]->present_parent = node_set[1];
	}
	fs >> M;
	for (int i = 0; i < M; i++) {
		int from, to;
		fs >> from >> to;
		node_set[from]->children.push_back(node_set[to]);
		node_set[to]->parents.push_back(node_set[from]);
	}

	if (k + 1 > N) {
	//	ofs << "k has to be less than N";
        return 0;
	}

    //  algorithm part
	int result[MAX];
	result[0] = 1;
	node_set[1]->selected = true;
	for (int i = 0; i <= k; i++) {
		//ofs << "round:" << i << endl;
		int benefit[500] = { 0 };
		for (int j = 1; j <= N; j++)
		{
			if (node_set[j]->selected == true) {
				benefit[j] = -1;
			}
			else {
				int root_benefit = node_set[j]->present_parent->value - node_set[j]->value;
				bool is_visited[500] = { 0 };
				calculate_benefit(node_set[j], node_set[j], &benefit[j], root_benefit, is_visited);
				benefit[j] += root_benefit;
				//ofs << j<<":"<<benefit[j]<<endl;
			}
		}
		int position = find_biggest_position(benefit, N);
		result[i + 1] = position;
		node* winner = node_set[position];
		change_children_present_father(winner, winner);
		node_set[position]->selected = true;
	}


    //  output part
    for (int i = 0; i < k; i++) {
        cout << result[i] << " -> ";
    }
    cout << result[k] << endl;

    //  free memory part
	for (int i = 1; i <= N; i++) {
		delete node_set[i];
	}
	delete[]node_set;

    //  ofs << "Done!" << endl;
    //  ofs.close();

    return 0;
}
